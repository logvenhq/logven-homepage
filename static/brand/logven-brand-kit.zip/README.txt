Logven brand kit

logven-lockup(.svg|.png)        Mark and wordmark, ink (#1d2027), for light backgrounds
logven-lockup-white(.svg|.png)  Mark and wordmark, white, for dark or photographic backgrounds
logven-mark(.svg|.png)          The mark alone, ink
logven-mark-white(.svg|.png)    The mark alone, white

Use the SVG files wherever possible. Keep clear space equal to the mark's
width on every side, don't recolour, stretch, rotate or add effects, and
don't set the wordmark yourself: always use these files.

Guidelines and colours: https://logven.com/brand/
Questions and co-branding approvals: info@logven.com
